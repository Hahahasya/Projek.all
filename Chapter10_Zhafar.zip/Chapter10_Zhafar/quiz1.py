num_list = [1, 2, 3, 6, 3, 2, 4, 5, 6,  2, 4]

result = 0

for num in num_list:
    result += num

print(result)